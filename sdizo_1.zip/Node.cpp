﻿#include "stdafx.h"
#include "Node.h"

Node::Node(int _data)
{
	data = _data;
}
