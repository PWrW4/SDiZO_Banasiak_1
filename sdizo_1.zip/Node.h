﻿#pragma once

class Node
{
public:
	int data;

	explicit Node(int _data);
};
